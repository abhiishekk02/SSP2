const getProducts = async () => {
  try {
    const response = await fetch("http://localhost:8080/data/getProducts");
    if (response.ok) {
      const data = await response.json();
      return data;
    } else {
      console.log("Failed to get data");
      return [];
    }
  } catch (error) {
    console.log(error.message, error);
    return [];
  }
};

const getCartProducts = () => {
  fetch(`http://localhost:8080/data/getCartProducts`)
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      return data;
    })
    .catch((error) => {
      console.error("Failed to fetch:", error);
    });
};

const displayProducts = async () => {
  const products = await getProducts();
  const cartProducts = await getCartProducts();
  const productContainer = document.querySelector(".products-list");
  productContainer.innerHTML = ""; //

  products.forEach((product) => {
    const card = document.createElement("div");
    card.classList.add("col-md-4");
    card.style.cursor = "pointer";
    card.onclick = () => {
      window.location.href = `productDetails.html?id=${product.id}`;
    };
    card.innerHTML = `
      <div class="card p-2">
        <p class="productName h4">${product.name}</p>
        <img src="${product.imageLink}" alt="Product Image" class="productImg img">
        <div class="row">
          <div class="col-md-6">
            <p class="productPrice h6">Rs${product.price}</p>
            <p class="productRating text-success h6">Rating: ${product.rating}</p>
          </div>
          <div class="col-md-6 h-100 mt-2 product-btn">
           
          
          </div>
        </div>
      </div>
    `;
    productContainer.appendChild(card);
  });
};

displayProducts();
